# NKP per-version deployment folders

Each version is a self-contained folder. To deploy a version, cd into it and run install.sh.

    nkp-deploy/
    ├── v2.17.0/   nkp.env · install.sh · certs/
    ├── v2.17.1/   nkp.env · install.sh · certs/   (CA chain pre-staged)
    ├── v2.18.0/   nkp.env · install.sh · certs/
    └── v2.18.1/   nkp.env · install.sh · certs/

## To deploy a version
    cd v2.17.1
    # 1) put cert files in certs/ (see certs/README.md). CA chain is pre-staged for 2.17.1.
    #    still need: nkp-ingress.crt, nkp-ingress.key, nkp-ssh.pub
    ssh-keygen -t ed25519 -f certs/nkp-ssh -N "" -C "nkp-nodes"   # if no ssh key yet
    # 2) review nkp.env (project, IPs, sizing)
    # 3) run — it validates certs on the fly, then creates the cluster
    ./install.sh

## What install.sh does (all-in-one)
1. Sources ./nkp.env
2. Checks all cert files exist
3. Validates the PC CA chain against the live PC (Verify return code: 0)
4. Installs the PC CA into the bastion OS trust store (preflight needs it)
5. Validates the ingress cert SAN covers the dashboard hostname + key matches
6. Validates Harbor reachability, CA trust, and that the version's project exists
7. Checks the LB range doesn't overlap the API VIP, warns on in-use LB IPs
8. Checks docker0 MTU 1442 (Flow VPC)
9. Loads the bootstrap image
10. Runs `nkp create cluster nutanix --airgapped --self-managed`

## Per-version differences
- `REGISTRY_MIRROR_PROJECT` / URL → the version's own Harbor project
  (2.17.0→nkp-2-17-0, 2.17.1→nkp-2-17-1, 2.18.0→nkp-2-18-0, 2.18.1→nkp-2-18-1)
- Bundle paths → that version's extracted tree under /mnt/nkp-sources/nkp-v<version>/
- KUBERNETES_VERSION + NODE_IMAGE_NAME → match the release
  (2.18.x values are placeholders — set the real K8s/image when known)

## IMPORTANT — IP planning (fixes the earlier ingress crashloop)
LB_IP_RANGE must NOT overlap node IPs or the API VIP. Default here is
10.68.24.125-130; confirm those are free and excluded from DHCP. The Kommander
dashboard hostname (nkp-prod.emeagso2026.local) must resolve to the Traefik
LoadBalancer IP (from the LB range) — NOT the API VIP (.105).

#!/bin/bash
# NKP 2.17.1 — create self-managed (management) cluster, air-gapped, TLS-verified.
# Run on the bastion AFTER:
#   set -a; source /mnt/nkp-sources/nkp-deploy.env; set +a
#   bash nkp-preflight.sh   # all green
#   docker load -i /mnt/nkp-sources/nkp-v2.17.1/konvoy-bootstrap-image-v2.17.1.tar
set -euo pipefail

# --- PC project (VMs are created in this PC project) ---
PROJECT_NAME="admins"             # Prism Central project for the cluster VMs

# --- derived: PC endpoint with port, and base64 PC CA bundle ---
PC_ENDPOINT="${NUTANIX_ENDPOINT}:${NUTANIX_PORT}"
PC_CA_B64="$(base64 -w0 "${PC_CA_CERT}")"     # --additional-trust-bundle wants base64

# --- separate push registry (your env has only the mirror; reuse Harbor host root) ---
# Mirror  = project path used to PULL air-gap images  (REGISTRY_MIRROR_URL -> .../nkp-2-17-1)
# Registry= a registry to PUSH app images to (here: same Harbor, project root or a push project)
DOCKER_REGISTRY="${REGISTRY_URL}"             # e.g. https://registry.emeagso2026.local  (adjust if a dedicated push project)

nkp create cluster nutanix \
  --cluster-name "${CLUSTER_NAME}" \
  --cluster-hostname "${CLUSTER_HOSTNAME}" \
  --endpoint "${PC_ENDPOINT}" \
  --additional-trust-bundle "${PC_CA_B64}" \
  --control-plane-endpoint-ip "${CONTROL_PLANE_ENDPOINT_IP}" \
  --control-plane-vm-image "${NODE_IMAGE_NAME}" \
  --control-plane-prism-element-cluster "${PRISM_ELEMENT_CLUSTER}" \
  --control-plane-subnets "${SUBNET_NAME}" \
  --control-plane-pc-project "${PROJECT_NAME}" \
  --control-plane-replicas "${CONTROL_PLANE_REPLICAS}" \
  --control-plane-vcpus "${CONTROL_PLANE_VCPUS}" \
  --control-plane-cores-per-vcpu "1" \
  --control-plane-memory "${CONTROL_PLANE_MEMORY_GIB}" \
  --worker-vm-image "${NODE_IMAGE_NAME}" \
  --worker-prism-element-cluster "${PRISM_ELEMENT_CLUSTER}" \
  --worker-subnets "${SUBNET_NAME}" \
  --worker-pc-project "${PROJECT_NAME}" \
  --worker-replicas "${WORKER_REPLICAS}" \
  --worker-vcpus "${WORKER_VCPUS}" \
  --worker-cores-per-vcpu "1" \
  --worker-memory "${WORKER_MEMORY_GIB}" \
  --ssh-public-key-file "${SSH_PUBLIC_KEY_FILE}" \
  --csi-storage-container "${NUTANIX_STORAGE_CONTAINER:-SelfServiceContainer}" \
  --csi-file-system "${CSI_FILESYSTEM:-ext4}" \
  --csi-hypervisor-attached-volumes="${CSI_HYPERVISOR_ATTACHED:-true}" \
  --kubernetes-service-load-balancer-ip-range "${LB_IP_RANGE}" \
  --kubernetes-pod-network-cidr="${POD_CIDR}" \
  --kubernetes-service-cidr="${SERVICE_CIDR}" \
  --airgapped \
  --self-managed \
  --registry-mirror-url "${REGISTRY_MIRROR_URL}" \
  --registry-mirror-username="${REGISTRY_USERNAME}" \
  --registry-mirror-password="${REGISTRY_PASSWORD}" \
  --registry-mirror-cacert "${REGISTRY_CACERT}" \
  --registry-url "${DOCKER_REGISTRY}" \
  --registry-username="${REGISTRY_USERNAME}" \
  --registry-password="${REGISTRY_PASSWORD}" \
  --registry-cacert "${REGISTRY_CACERT}" \
  --bootstrap-cluster-image "${BOOTSTRAP_IMAGE}" \
  --wait

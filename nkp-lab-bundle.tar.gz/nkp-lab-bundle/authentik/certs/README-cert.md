# Authentik TLS cert (authentik.emeagso2026.local)

Authentik needs its own cert because the DNS alias authentik.emeagso2026.local
isn't in the registry cert's SAN. Issue a dedicated leaf from AD CS.

## 1. Generate key + CSR (on the registry/authentik host or any Linux box)
```bash
openssl req -new -newkey rsa:4096 -nodes \
  -keyout authentik.key \
  -out authentik.csr \
  -config authentik-csr.cnf
# verify the SAN is in the CSR:
openssl req -in authentik.csr -noout -text | grep -A1 "Subject Alternative Name"
#   -> DNS:authentik.emeagso2026.local
```

## 2. Submit to AD CS FROM FILE (not the web form)
The certsrv web form + AD CS rebuild the SAN and can corrupt base64. Submit the
CSR file directly so the SAN in the CSR is honored:
```powershell
# on a box that can reach the CA (or copy authentik.csr to the CA):
certreq -submit -attrib "CertificateTemplate:WebServer" authentik.csr authentik.crt
# if the template enforces its own SAN, request one that allows SAN in the CSR,
# or set the CA to honor CSR SANs (EDITF_ATTRIBUTESUBJECTALTNAME2) — lab only.
```
Retrieve `authentik.crt` (the leaf).

## 3. Build the fullchain + verify
```bash
# fullchain = leaf + issuing CA (+ root), leaf first
cat authentik.crt ca-chain.crt > authentik-fullchain.crt

# key <-> cert match (must be identical):
openssl x509 -noout -modulus -in authentik.crt | openssl md5
openssl rsa  -noout -modulus -in authentik.key | openssl md5

# SAN present?
openssl x509 -in authentik.crt -noout -ext subjectAltName
#   -> DNS:authentik.emeagso2026.local
```

## 4. Place for Authentik (docker-compose mounts ./certs -> /certs)
Authentik auto-loads certs from its cert dir. Put:
```
certs/authentik-fullchain.crt
certs/authentik.key
```
Then in the Authentik UI: System → Certificates → the cert appears (or import),
and set it as the web cert under System → Settings / Brand, or per-provider.

Alternatively, if you front Authentik with nginx on this host, point nginx at
authentik-fullchain.crt + authentik.key and proxy to authentik's :9000.

## Note — the DNS record must exist first
authentik.emeagso2026.local  A  10.68.24.103   (in AD DNS)
The cert SAN and the DNS name must match, or TLS validation fails.

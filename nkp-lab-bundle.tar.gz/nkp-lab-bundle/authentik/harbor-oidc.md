# Harbor ↔ Authentik OIDC (AD login for the registry too)

Make Harbor (registry.emeagso2026.local:443) authenticate against Authentik/AD,
so the registry UI uses the same SSO as the portal. Harbor speaks OIDC natively.

## 1. In Authentik — create an OAuth2/OIDC Provider
Applications → Providers → Create → **OAuth2/OpenID Provider**:
- **Name:** `harbor-oidc`
- **Authorization flow:** default-provider-authorization-implicit-consent
- **Client type:** Confidential
- **Redirect URIs** (exact):
    https://registry.emeagso2026.local/c/oidc/callback
- **Signing key:** the default authentik self-signed (or your PKI key)
- **Scopes:** openid, email, profile
- Save, then note the **Client ID** and **Client Secret**.

Applications → Create:
- **Name:** `Harbor Registry`  **Slug:** `harbor`
- **Provider:** `harbor-oidc`
- (optional) bind an AD group policy (e.g. only `nkp-admins`).

The OIDC issuer URL will be:
    https://registry.emeagso2026.local:9443/application/o/harbor/

Get the exact endpoints from:
    https://registry.emeagso2026.local:9443/application/o/harbor/.well-known/openid-configuration

## 2. In Harbor — Administration → Configuration → Authentication
Switch **Auth Mode** to **OIDC** (only possible before any non-admin users exist,
or as the admin). Fill:
- **OIDC Provider Name:** Authentik
- **OIDC Endpoint:** `https://registry.emeagso2026.local:9443/application/o/harbor/`
- **OIDC Client ID:** (from step 1)
- **OIDC Client Secret:** (from step 1)
- **Group Claim Name:** `groups`
- **OIDC Scope:** `openid,email,profile,offline_access`
- **Verify Certificate:** ON (Harbor must trust the internal CA — see step 3)
- **Automatic onboarding:** ON (creates Harbor users on first OIDC login)
- **Username Claim:** `preferred_username`
- Save → "Test OIDC Server" must succeed.

## 3. Harbor must trust the Authentik cert
Authentik serves TLS signed by your internal PKI. Harbor's core container needs
the CA chain, or the OIDC handshake fails (x509 unknown authority — same class
of issue as everywhere else in this lab).

Since Harbor pulls the CA from the host trust store baked at deploy, ensure the
registry host trusts the chain (it already does for the registry cert). If the
"Test OIDC Server" fails on TLS, add the chain into Harbor's trust:
```bash
# copy CA chain into harbor's internal trust dir and restart core
sudo cp /opt/harbor/certs/registry-ca-chain.crt \
        /data/ca_bundle/authentik-ca.crt 2>/dev/null || \
  echo "set 'Root Certificate' in harbor.yml or mount the CA into the core container"
sudo docker restart harbor-core
```
Alternatively set `AUTHENTIK_no-verify` off and rely on the host trust store which
already has SUBCA+ROOT installed (from the earlier update-ca-trust step).

## 4. Login flow
Registry UI → "LOGIN VIA OIDC PROVIDER" button → Authentik → AD creds →
back to Harbor, auto-onboarded. `docker login` / `nkp push` still work with the
**CLI secret** (Harbor UI → user → CLI secret) instead of the AD password.

## Gotcha — the admin account
Keep the local Harbor `admin` account working as a break-glass. OIDC users can't
use `docker login` with their AD password; they use the per-user CLI secret. The
`admin`/`Harbor12345` local login stays available at `.../account/sign-in?...`.

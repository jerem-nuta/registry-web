# Authentik SSO for the emeagso2026 lab (standalone → later on NKP)

Single AD-backed login for the portal + downloader. Users authenticate once
against **Active Directory** via Authentik; every gated page then opens without
re-login. Forward-auth (Proxy Provider) model — nginx asks Authentik, Authentik
checks AD, sets a session cookie for the lab domain.

```
AD (LDAPS) ──► Authentik (IdP) ──► embedded outpost (forward-auth) ──► nginx :8080/:8445 ──► portal
```

## 0. Prerequisites
- A host to run Authentik (VM like the registry). 2 vCPU / 4 GB min.
- Docker + compose v2.
- DNS: `authentik.emeagso2026.local` → the Authentik host IP.
- A TLS cert for that FQDN from your AD CS (SAN = authentik.emeagso2026.local).
- The internal CA chain (`ca-chain.crt`, SUBCA+ROOT) in `./certs/`.

## 1. Get the images into Harbor

**Scenario A — Harbor host has internet (DMZ, your case).** Pull directly on the
Harbor host and push to a private `authentik` project. No save/load transfer.
```bash
# on the Harbor host (it can reach the internet)
docker login registry.emeagso2026.local -u admin -p Harbor12345
# create the harbor project 'authentik' first (UI or API), then:
for pair in \
  "ghcr.io/goauthentik/server:2025.6.4=registry.emeagso2026.local/authentik/goauthentik/server:2025.6.4" \
  "docker.io/library/postgres:16-alpine=registry.emeagso2026.local/authentik/library/postgres:16-alpine" \
  "docker.io/library/redis:alpine=registry.emeagso2026.local/authentik/library/redis:alpine" ; do
  src="${pair%%=*}"; dst="${pair##*=}"
  docker pull "$src"; docker tag "$src" "$dst"; docker push "$dst"; done
```

Even simpler with the Docker Hub / GHCR pull-through cache (see note below): point
the compose `REGISTRY` at the cache project and Harbor fetches on first pull.

**Scenario B — fully air-gapped Harbor.** Pull elsewhere, save, transfer, load, push:
```bash
# on an internet box:
for img in ghcr.io/goauthentik/server:2025.6.4 docker.io/library/postgres:16-alpine docker.io/library/redis:alpine; do docker pull "$img"; done
docker save ghcr.io/goauthentik/server:2025.6.4 library/postgres:16-alpine library/redis:alpine -o authentik-images.tar
# transfer authentik-images.tar in, then on the Harbor host: docker load -i, retag, push (as in Scenario A)
```

## 2. Configure + start
```bash
cp env.example .env
# generate the secrets:
sed -i "s|CHANGE_ME_pg_password|$(openssl rand -base64 36)|" .env
sed -i "s|CHANGE_ME_secret_key|$(openssl rand -base64 60)|"  .env
mkdir -p certs && cp /path/to/ca-chain.crt certs/    # internal CA (SUBCA+ROOT)

docker compose up -d
# first boot runs migrations; then open the initial setup:
#   https://authentik.emeagso2026.local:9443/if/flow/initial-setup/
# set the akadmin password.
```

## 3. Connect Active Directory (LDAP source)
In the Authentik UI → **Directory → Federation & Social login → Create → LDAP Source**:
- **Server URI:** `ldaps://<your-DC-fqdn>:636` (LDAPS; needs the AD cert trusted — that's why ca-chain.crt is mounted)
- **Bind CN:** a read-only AD service account DN, e.g. `CN=svc-authentik,OU=Service,DC=emeagso2026,DC=local`
- **Bind Password:** that account's password
- **Base DN:** `DC=emeagso2026,DC=local`
- **Property mappings:** the default "authentik default LDAP Mapping: *" set + the Active Directory ones
- Enable **Sync users** + **Sync groups**. Save, then **Run sync** and check the sync status.

AD users/groups now appear under **Directory → Users / Groups**.

## 4. Create the forward-auth Proxy Provider + Application
**Providers → Create → Proxy Provider:**
- **Name:** `portal-forward-auth`
- **Authorization flow:** default-provider-authorization-implicit-consent
- **Forward auth (single application)** mode
- **External host:** `https://registry.emeagso2026.local:8080`
- Save.

**Applications → Create:**
- **Name:** `NKP Portal`, **Slug:** `nkp-portal`
- **Provider:** `portal-forward-auth`
- (optional) bind a **Policy** so only an AD group (e.g. `nkp-admins`) can access.

**Outposts → the embedded outpost → Edit → add the `NKP Portal` application.**
The embedded outpost serves the `/outpost.goauthentik.io/` endpoints nginx calls.

## 5. Wire nginx (registry host)
Replace the basic-auth `server { listen 8080 }` block in
`/etc/nginx/conf.d/nkp-sources.conf` with the one in `nginx-forward-auth.conf`
(adjust the `authentik.emeagso2026.local:9443` upstream to your Authentik host).
```bash
sudo nginx -t && sudo systemctl reload nginx
```
Repeat for the downloader (8445) if you want it gated too — same auth_request lines.

## 6. Test
- Open `https://registry.emeagso2026.local:8080/` → redirected to Authentik →
  log in with an **AD** user → bounced back to the portal, now open.
- Open the downloader / file browser → **no second login** (same session cookie).

## 7. Later: move onto the NKP management cluster
Once NKP is up, redeploy Authentik as a Kommander/Helm app on the cluster,
front it with the cluster ingress (Traefik) + cert-manager, and point the same
LDAP source at AD. The forward-auth model stays identical; only the host moves.
This is why we kept it containerised + config-as-data here.

## Notes / gotchas
- **LDAPS cert trust:** AD's LDAPS cert must chain to a CA in ca-chain.crt, or
  the LDAP sync fails with a TLS error (same class of issue as the PC/registry certs).
- **Cookie domain:** the session cookie is scoped to the host. For true cross-port
  SSO (8080 ↔ 8445) they share the host `registry.emeagso2026.local`, so the cookie
  carries over. Harbor (443) is a separate app; wire it via its own OIDC to Authentik if wanted.
- **Never use `:latest`** for the authentik image — pin the tag (frozen past 2025.2).
- Rotate `PG_PASS` and `AUTHENTIK_SECRET_KEY`; treat `.env` as a secret.

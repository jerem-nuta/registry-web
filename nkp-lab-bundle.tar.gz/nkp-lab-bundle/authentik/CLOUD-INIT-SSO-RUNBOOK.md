# Authentik SSO via cloud-init — runbook

How to bring up Authentik SSO for the emeagso2026 lab **from the registry
cloud-init** (`cloud-init-harbor.yml`). Authentik runs on the registry host,
reuses the registry TLS cert, and gates the portal behind one AD-backed login.

```
AD (LDAPS) ──► Authentik (on registry host, :9443) ──► nginx forward-auth ──► portal :8080 / downloader :8445
                     └── OIDC ──► Harbor :443
```

Everything below is already wired in the cloud-init. You flip two toggles and do
the Authentik UI config (LDAP + provider) that can't be scripted.

---

## What the cloud-init already does for you

On boot, with the toggles on, the cloud-init:

- Embeds the registry cert (`registry-fullchain.crt` / `registry.key` /
  `registry-ca-chain.crt`) — Harbor and Authentik share it.
- Writes the **forward-auth nginx variant** + `sso-toggle.sh on|off` helper.
- If `DEPLOY_AUTHENTIK=true`: generates secrets, copies the registry cert into
  `/opt/authentik/certs/`, writes `/opt/authentik/docker-compose.yml`, and starts
  **server + worker + postgres + redis** — pulling images from Harbor's
  pull-through caches (ghcr + dockerhub).
- If `SSO_ENABLED=true`: activates the forward-auth config so the portal is gated.

---

## Step 1 — set the toggles

Edit these in `cloud-init-harbor.yml` before deploying the registry VM (they sit
together in the tunables block):

```bash
# bring Authentik up on this host, on boot
DEPLOY_AUTHENTIK="true"

# gate the portal behind Authentik. Leave "false" for the FIRST boot — turn it on
# only AFTER Authentik is configured (step 4), or the portal locks you out before
# there's anything to log in with. You can flip it live later with sso-toggle.sh.
SSO_ENABLED="false"

# Authentik is addressed here (reuses the registry cert — same host, port 9443)
AUTHENTIK_HOST="registry.emeagso2026.local:9443"

# pinned version + image sources (DMZ pull-through resolves these automatically)
AUTHENTIK_TAG="2025.6.4"
AUTHENTIK_IMAGE="registry.emeagso2026.local/ghcr/goauthentik/server"
AUTHENTIK_PG_IMAGE="registry.emeagso2026.local/dockerhub/library/postgres:16-alpine"
AUTHENTIK_REDIS_IMAGE="registry.emeagso2026.local/dockerhub/library/redis:alpine"
```

**Recommended first-boot combo:** `DEPLOY_AUTHENTIK=true`, `SSO_ENABLED=false`.
Authentik comes up but the portal stays on basic auth until you're ready.

---

## Step 2 — deploy the registry VM

Deploy the VM with this cloud-init as usual. When it boots (DMZ, so it can pull):

- Harbor comes up, pull-through caches (dockerhub, ghcr) + projects are created.
- Authentik containers start; images pulled via the ghcr/dockerhub caches.
- Portal (:8080), file browser (:8080/files/), downloader (:8445) come up.

Verify Authentik started:
```bash
ssh harbor@registry.emeagso2026.local
docker ps | grep -E 'authentik|postgres|redis'
# server + worker + postgresql + redis should be Up
```

If the Authentik containers aren't up (image pull raced ahead of Harbor being
ready on a cold boot), just re-run:
```bash
cd /opt/authentik && docker compose up -d
```

---

## Step 3 — finish Authentik initial setup

Open the initial-setup flow and set the admin (`akadmin`) password:
```
https://registry.emeagso2026.local:9443/if/flow/initial-setup/
```
(The cert is the registry cert, so the name in the URL matches the SAN — no TLS
warning if your machine trusts the internal CA.)

---

## Step 4 — connect Active Directory (LDAP source)

In the Authentik UI → **Directory → Federation & Social login → Create → LDAP Source**:

| Field | Value |
|-------|-------|
| Server URI | `ldaps://<your-DC-fqdn>:636` (LDAPS) |
| Bind CN | read-only AD service account DN, e.g. `CN=svc-authentik,OU=Service,DC=emeagso2026,DC=local` |
| Bind Password | that account's password |
| Base DN | `DC=emeagso2026,DC=local` |
| Property mappings | the default LDAP set + the Active Directory ones |
| Sync users / groups | enabled |

Save → **Run sync** → check the sync status. AD users/groups appear under
**Directory → Users / Groups**.

> LDAPS needs AD's cert to chain to a CA in `ca-chain.crt` (mounted into Authentik
> at `/certs`). If sync fails with a TLS error, that's the cause — same class of
> issue as the PC/registry certs.

---

## Step 5 — create the forward-auth Proxy Provider + Application

**Providers → Create → Proxy Provider:**
- Name: `portal-forward-auth`
- Authorization flow: `default-provider-authorization-implicit-consent`
- Mode: **Forward auth (single application)**
- External host: `https://registry.emeagso2026.local:8080`

**Applications → Create:**
- Name: `NKP Portal`, Slug: `nkp-portal`
- Provider: `portal-forward-auth`
- (optional) bind a Policy so only an AD group (e.g. `nkp-admins`) gets in.

**Outposts → embedded outpost → Edit → add `NKP Portal`.**
The embedded outpost serves the `/outpost.goauthentik.io/` endpoints nginx calls.

---

## Step 6 — turn on SSO

Now that Authentik can authenticate AD users, gate the portal. Either:

**Live (no reboot):**
```bash
sudo /usr/local/bin/sso-toggle.sh on registry.emeagso2026.local:9443
```

**Or on next deploy:** set `SSO_ENABLED="true"` in the cloud-init.

Revert anytime:
```bash
sudo /usr/local/bin/sso-toggle.sh off
```

---

## Step 7 — (optional) Harbor login via AD too

Wire Harbor's OIDC to Authentik so the registry UI uses the same login.
See `harbor-oidc.md`. Summary: create an OAuth2/OIDC provider in Authentik
(redirect `https://registry.emeagso2026.local/c/oidc/callback`), switch Harbor
Auth Mode → OIDC, point it at
`https://registry.emeagso2026.local:9443/application/o/harbor/`.

---

## Step 8 — test

- `https://registry.emeagso2026.local:8080/` → redirected to Authentik →
  log in with an **AD** user → bounced back to the portal, now open.
- Open the file browser / downloader → **no second login** (shared host cookie).
- (if step 7) Harbor UI → "LOGIN VIA OIDC" → same AD login.

---

## Toggle reference

| Toggle | Effect |
|--------|--------|
| `DEPLOY_AUTHENTIK=true` | cloud-init starts the Authentik stack on boot |
| `SSO_ENABLED=true` | portal (8080) gated by Authentik on boot |
| `sso-toggle.sh on\|off` | flip the portal gate live, no reboot |

## Gotchas

- **First boot:** keep `SSO_ENABLED=false` until AD + provider are configured,
  or the portal has nothing to authenticate against.
- **Cold-boot race:** Authentik pulls its images from Harbor; if Harbor isn't
  pullable yet, re-run `cd /opt/authentik && docker compose up -d`.
- **LDAPS cert trust:** AD's cert must chain to `ca-chain.crt` or sync fails.
- **Break-glass:** keep Harbor's local `admin` account; OIDC users use per-user
  CLI secrets for `docker login` / `nkp push`, not their AD password.
- **Later — dedicated identity:** to move Authentik off the registry name (e.g.
  onto the NKP cluster), give it `authentik.emeagso2026.local` + its own cert
  (`certs/README-cert.md` + `certs/authentik-csr.cnf`), then repoint `AUTHENTIK_HOST`.
- **Secrets:** the cloud-init generates `PG_PASS` + `AUTHENTIK_SECRET_KEY` at boot
  and writes them to `/opt/authentik/.env` — treat that file as sensitive.

# NKP 2.17.1 Air-Gapped Lab — full bundle

emeagso2026 NKP lab: registry portal, per-version deploy folders, Authentik SSO
(now folded into the registry cloud-init), and runbooks.

## Layout
```
registry-web/     Portal + pages served on the registry (:8080).
  index.html            portal home — now includes the Authentik SSO card (:9443)
  nkp-stack.html        radial stack map (version labels removed)
  nkp-checklist.html    deploy runbook (air-gap / DMZ modes, version picker)
  nkp-env-builder.html  env generator (deployment save/load, PC_FQDN, image K8s check,
                        nkp-only image filter, help modal)
  nkp-downloader.html   static link->curl page (version-aware)
  versions.json         SINGLE SOURCE OF TRUTH for versions
  downloader-backend/   live downloader (:8445): sequential queue, per-version dest,
                        per-file push button — app.py, page.html, Dockerfile, compose

registry/         Harbor host first-boot.
  cloud-init-harbor.yml   Harbor + portal + downloader + per-version projects +
                          dockerhub/ghcr pull-through caches + SSO toggle +
                          Authentik deploy (DEPLOY_AUTHENTIK, reuses registry cert) +
                          encrypted/plain bundle fetch

bastion/          Bastion first-boot + NFS mount helpers.

deploy/           Per-version self-contained folders: v2.17.0 / v2.17.1 / v2.18.0 / v2.18.1
                  each = nkp.env + install.sh (validate certs on the fly) + certs/
                  plus standalone nkp-prod.env, nkp-preflight.sh, nkp-create-cluster.sh

authentik/        SSO package (standalone-now, cluster-later).
  docker-compose.yml, env.example
  CLOUD-INIT-SSO-RUNBOOK.md   full deploy+config runbook via the cloud-init
  README.md                   standalone deploy runbook
  nginx-forward-auth.conf     gate the portal behind Authentik
  harbor-oidc.md              Harbor UI login via Authentik/AD
  certs/README-cert.md + authentik-csr.cnf   dedicated-cert path (for later)

docs/             README.md, RUNBOOK.md, PC-SERVICE-ACCOUNT.md

## Add a new NKP version (one file)
Edit versions.json → every page + the registry cloud-init read it. Then create the
Harbor project + folder (or let the downloader auto-create the folder on first pull).

## Deploy order
1. registry/cloud-init-harbor.yml -> Harbor host (set DEPLOY_AUTHENTIK=true for SSO)
2. bastion/ -> bastion
3. Stage bundles (downloader) -> push to Harbor
4. deploy/v<ver>/ -> cd in, add certs, ./install.sh
5. Authentik: finish setup at https://registry.emeagso2026.local:9443/ then wire AD
   (see authentik/CLOUD-INIT-SSO-RUNBOOK.md); flip SSO with sso-toggle.sh on

## Key fixes baked in
- nginx /files/ listing: index index.nonexistent (index ""; is invalid)
- Authentik worker /certs mount must be WRITABLE (worker chowns it; :ro crash-loops)
- Authentik reuses the registry cert on :9443 (no new cert for now)
- LB range must not overlap node IPs / API VIP; dashboard FQDN -> Traefik LB, not VIP
- PC CA must be in the bastion OS trust store (preflight uses system store)

## Notes
- Lab creds (admin/Harbor12345, PC password) are lab-only — rotate for real use.
- Signed download.nutanix.com URLs shared in chat are exposed — regenerate them.

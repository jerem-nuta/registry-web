# NKP 2.17.1 Air-Gapped Lab — full bundle

Everything for the emeagso2026 NKP lab: registry portal, deploy folders,
Authentik SSO, and runbooks.

## Layout
```
registry-web/     The portal + pages served on the registry (:8080). Push to the
                  registry-web git repo, pull onto /data/nkp-sources/.
  index.html            portal home (cards)
  nkp-stack.html        radial stack-component map
  nkp-checklist.html    step-by-step deploy runbook (air-gap / DMZ modes)
  nkp-env-builder.html  env generator (deployment save/load, PC_FQDN, image K8s check)
  nkp-downloader.html   static link->curl page (version-aware)
  versions.json         SINGLE SOURCE OF TRUTH for versions — edit to add one
  downloader-backend/   live downloader (:8445): sequential queue, per-version dest
                        app.py, page.html, Dockerfile, docker-compose.yml

registry/         The Harbor host first-boot.
  cloud-init-harbor.yml   Harbor + portal + downloader + per-version projects +
                          dockerhub/ghcr pull-through caches + SSO toggle
  harbor-auto-cloud-init.yml  (earlier variant)

bastion/          Bastion first-boot + NFS mount helpers.

deploy/           Per-version, self-contained deploy folders.
  v2.17.0 / v2.17.1 / v2.18.0 / v2.18.1
      nkp.env       version-specific env (project, bundles, PC, sizing)
      install.sh    all-in-one: source env -> validate certs on the fly -> create
      certs/        paste PEM here (2.17.1 has the CA chain pre-staged)
  nkp-prod.env, nkp-preflight.sh, nkp-create-cluster.sh  standalone scripts

authentik/        Standalone SSO (AD-backed), later movable to the NKP cluster.
  docker-compose.yml, env.example, README.md
  nginx-forward-auth.conf   gate the portal behind Authentik
  harbor-oidc.md            Harbor UI login via Authentik/AD

docs/             README.md, RUNBOOK.md, PC-SERVICE-ACCOUNT.md

## Add a new NKP version (one-file change)
Edit versions.json (add {version,k8s,default}). Every page + the registry
cloud-init reads it. Then create the Harbor project + folder (or let the
downloader auto-create the folder on first download).

## Deploy order
1. registry/cloud-init-harbor.yml  -> Harbor host
2. bastion/                        -> bastion
3. Stage bundles (downloader) -> push to Harbor
4. deploy/v<ver>/                  -> cd in, add certs, ./install.sh
5. authentik/ (optional)           -> SSO, then flip sso-toggle.sh on

## Notes
- Air-gap vs DMZ: Harbor can reach internet (pull-through caches live); the
  cluster still pulls only from Harbor. Checklist has both modes.
- Signed download.nutanix.com URLs shared in chat are exposed — rotate them.
- Lab creds (admin/Harbor12345, PC password) are lab-only — rotate for real use.

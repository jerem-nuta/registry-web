# registry/ — Harbor host payload (fetched by the slim cloud-init)

The slim cloud-init (cloud-init-harbor-slim.EXAMPLE.yml) is a ~240-line bootstrap.
It handles ONLY user/password/SSH + the registry cert+key (secret), then fetches
this bundle and runs install-harbor.sh from here.

## Files (all edited as normal files, not embedded in YAML)
- install-harbor.sh      the full installer (Harbor, portal, downloader, Authentik)
- nkp-sources.conf       nginx portal/file-server (8080)
- nkp-sources-sso.conf   nginx forward-auth variant
- sso-toggle.sh          basic-auth <-> Authentik SSO switch
- harbor.yml             Harbor config
- nkp-theme.css          Harbor UI theme
- rootca.crt/issuingca.crt  internal CA chain (public, fine in git)

## Deploy
1. Take cloud-init-harbor-slim.EXAMPLE.yml, paste your REAL registry.crt + registry.key
   into the two cert blocks (they're kept out of this public bundle on purpose).
2. Deploy the VM with that cloud-init.
3. It fetches this bundle and runs registry/install-harbor.sh automatically.

## The secret cert/key
NOT in this bundle. They live only in your cloud-init (which you keep private).

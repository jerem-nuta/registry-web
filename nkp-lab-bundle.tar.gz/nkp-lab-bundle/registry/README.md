# registry/ — Harbor host payload (fetched by the slim cloud-init)

The slim cloud-init (cloud-init-harbor-slim.EXAMPLE.yml) is a ~250-line bootstrap.
It handles ONLY user/password/SSH + the registry cert+key (secret), then fetches
this bundle and runs install-harbor.sh from here.

## DEFAULT DESIGN (out of the box)
- **Harbor registry (443):** local super-admin `admin` / `Harbor12345` (always works).
- **Portal + files + upload + env-builder (8080):** BASIC AUTH `admin` / `Harbor12345`.
- **Downloader (8445):** BASIC AUTH (same shared login).
- **HTML pages:** no auth BETWEEN pages — one basic-auth prompt at the nginx layer, then
  all pages are browsable. No per-page login.
- **Authentik:** NOT deployed on this host by default (DEPLOY_AUTHENTIK=false).
  Runs on a SEPARATE server. All hooks stay in place so you can opt in.

## Making Authentik optional (two independent switches, both in install-harbor.sh TUNABLES)
1. DEPLOY_AUTHENTIK=true  -> ALSO run Authentik containers on THIS host (all-in-one lab).
   Leave false to keep this a Harbor-only host and run Authentik elsewhere.
2. SSO_ENABLED=true (or run `sudo sso-toggle.sh on <authentik_host:port>` later)
   -> gate the 8080 portal behind Authentik forward-auth instead of basic auth.
   `sudo sso-toggle.sh off` reverts to basic auth. Point AUTHENTIK_HOST at wherever
   Authentik actually runs (default: authentik.emeagso2026.local:9443).

Harbor OIDC (AD login for the registry UI) is configured in the Harbor UI against your
external Authentik — the local admin always remains as break-glass.

## Files
- install-harbor.sh      the installer (Harbor, portal, downloader; Authentik optional)
- nkp-sources.conf       nginx portal/file-server (8080) — BASIC AUTH (default)
- nkp-sources-sso.conf   nginx forward-auth variant (used when sso-toggle.sh on)
- sso-toggle.sh          basic-auth <-> Authentik SSO switch
- harbor.yml             Harbor config
- nkp-theme.css          Harbor UI theme
- rootca.crt/issuingca.crt  internal CA chain (public, fine in git)

## Deploy
1. Take cloud-init-harbor-slim.EXAMPLE.yml, paste your REAL registry.crt + registry.key
   into the two cert blocks (kept out of this public bundle on purpose), set a fresh
   Docker Hub token if you want an authenticated cache.
2. VALIDATE: python3 -c "import yaml; yaml.safe_load(open('cloud-init-harbor-slim.yml'))"
3. Deploy the VM with that cloud-init. It fetches this bundle + runs registry/install-harbor.sh.

## The secret cert/key + Docker Hub token
NOT in this bundle. They live only in your private cloud-init.

#!/usr/bin/env bash
# Usage: sso-toggle.sh on|off [authentik_host:port]
# on  -> gate the 8080 portal behind Authentik forward-auth
# off -> revert to basic auth
set -euo pipefail
MODE="${1:-}"; AH="${2:-authentik.emeagso2026.local:9443}"
BASIC=/etc/nginx/conf.d/nkp-sources.conf
SSO_SRC=/opt/harbor/nginx-sso/nkp-sources-sso.conf
BASIC_BAK=/opt/harbor/nginx-sso/nkp-sources-basic.conf.bak
case "$MODE" in
  on)
    [ -f "$BASIC_BAK" ] || cp "$BASIC" "$BASIC_BAK"
    sed "s/__AUTHENTIK_HOST__/${AH}/g" "$SSO_SRC" > "$BASIC"
    echo "SSO ON — portal gated by Authentik at ${AH}";;
  off)
    [ -f "$BASIC_BAK" ] && cp "$BASIC_BAK" "$BASIC" || { echo "no basic backup found"; exit 1; }
    echo "SSO OFF — portal back on basic auth";;
  *) echo "usage: sso-toggle.sh on|off [authentik_host:port]"; exit 1;;
esac
nginx -t && systemctl reload nginx && echo "nginx reloaded"

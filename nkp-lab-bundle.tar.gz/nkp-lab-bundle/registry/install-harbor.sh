#!/usr/bin/env bash
set -euxo pipefail
MARKER=/var/lib/harbor-install.done
[ -f "$MARKER" ] && exit 0

      # === stage config files shipped in the bundle (registry/ payload) into place ===
      # This script now lives in the tar bundle alongside its config files. Copy them
      # to the locations the rest of the install expects (previously written by cloud-init).
      PAYLOAD="$(dirname "$(readlink -f "$0")")"
      install -d -m0755 /etc/nginx/conf.d /opt/harbor/nginx-sso /opt/harbor/theme /opt/harbor/certs /etc/pki/ca-trust/source/anchors
      [ -f "$PAYLOAD/nkp-sources.conf"     ] && cp "$PAYLOAD/nkp-sources.conf"     /etc/nginx/conf.d/nkp-sources.conf
      [ -f "$PAYLOAD/nkp-sources-sso.conf" ] && cp "$PAYLOAD/nkp-sources-sso.conf" /opt/harbor/nginx-sso/nkp-sources-sso.conf
      [ -f "$PAYLOAD/sso-toggle.sh"        ] && cp "$PAYLOAD/sso-toggle.sh"        /usr/local/bin/sso-toggle.sh && chmod 0755 /usr/local/bin/sso-toggle.sh
      [ -f "$PAYLOAD/nkp-theme.css"        ] && cp "$PAYLOAD/nkp-theme.css"        /opt/harbor/theme/nkp-theme.css
      [ -f "$PAYLOAD/harbor.yml"           ] && cp "$PAYLOAD/harbor.yml"           /opt/harbor/harbor.yml
      [ -f "$PAYLOAD/rootca.crt"           ] && cp "$PAYLOAD/rootca.crt"           /etc/pki/ca-trust/source/anchors/rootca.crt
      [ -f "$PAYLOAD/issuingca.crt"        ] && cp "$PAYLOAD/issuingca.crt"        /etc/pki/ca-trust/source/anchors/issuingca.crt
      # (registry.crt + registry.key come from cloud-init — secrets stay out of the bundle)


# ======================= TUNABLES (edit me) ======================
# --- SINGLE SHARED LOGIN across Harbor (443), portal (8080), downloader (8445) ---
SHARED_USER="admin"
SHARED_PASSWORD="Harbor12345"   # one password for all three services

HARBOR_VERSION="v2.15.1"
# NKP versions to host. Each gets its own Harbor mirror project (nkp-<ver dashed>)
# and a source folder /data/nkp-sources/nkp-v<ver>/.
# Single source of truth: /data/nkp-sources/versions.json (the web pages read the same file).
# Fallback list is used only if versions.json is absent/unparseable.
NKP_VERSIONS="2.17.0 2.17.1 2.18.0 2.18.1"
if [ -f /data/nkp-sources/versions.json ]; then
  _VJSON="$(grep -oE '"version"[[:space:]]*:[[:space:]]*"[^"]+"' /data/nkp-sources/versions.json | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | tr '\n' ' ')"
  [ -n "$_VJSON" ] && NKP_VERSIONS="$_VJSON"
fi
FQDN="registry.emeagso2026.local"
# NFS export is restricted to these bastion IP(s). Space-separated list —
# add a new bastion's IP here to grant it access (e.g. "10.68.24.102 10.68.24.112").
BASTION_IPS="10.68.24.102"

# --- SSO (Authentik forward-auth) ---
# SSO_ENABLED=false -> the 8080 portal uses basic auth (works standalone, day 1).
# SSO_ENABLED=true  -> the 8080 portal is gated by Authentik (requires Authentik up).
# Both configs are written to disk; a helper (sso-toggle.sh) flips between them
# so you can switch AFTER Authentik is deployed, with no hand-editing.
SSO_ENABLED="false"
# NOW: Authentik reuses the registry host+cert on port 9443.
# LATER: switch to authentik.emeagso2026.local once it has its own cert.
AUTHENTIK_HOST="registry.emeagso2026.local:9443"
# DEPLOY_AUTHENTIK=true -> this cloud-init also brings up the Authentik containers
# (server+worker+postgres+redis) on this host, reusing the registry cert. Requires
# the images in Harbor (DMZ pull-through handles ghcr/dockerhub automatically).
DEPLOY_AUTHENTIK="true"
AUTHENTIK_TAG="2025.6.4"
# image sources (DMZ: pull-through caches resolve these; air-gap: pre-push to these paths)
AUTHENTIK_IMAGE="registry.emeagso2026.local/ghcr/goauthentik/server"
AUTHENTIK_PG_IMAGE="registry.emeagso2026.local/dockerhub/library/postgres:16-alpine"
AUTHENTIK_REDIS_IMAGE="registry.emeagso2026.local/dockerhub/library/redis:alpine"

# --- CRED SET 1: Harbor admin (registry UI + API login) ---
HARBOR_ADMIN_PASSWORD="${SHARED_PASSWORD}"

# --- CRED SET 2: Docker Hub account (proxy cache -> real hub.docker.com) ---
#     Leave BOTH empty for an anonymous cache (lower rate limit).
DOCKERHUB_USER=""
DOCKERHUB_TOKEN=""
# real token injected privately by the slim cloud-init (kept OUT of the public bundle):
[ -f /opt/harbor/dockerhub.env ] && . /opt/harbor/dockerhub.env || true

# --- CRED SET 3: File server + upload portal login (custom HTTPS) ---
FILES_USER="${SHARED_USER}"
FILES_PASSWORD="${SHARED_PASSWORD}"   # shared with Harbor + downloader (no longer generated)
# --- GIT SOURCE: web pages + backend (point at GitHub OR internal Gitea) ---
# Two delivery modes — pick one:
#
# MODE A (BUNDLE, default): fetch ONE encrypted tar from a public repo, decrypt,
#   and unpack the whole registry-web/ tree. Add a version = rebuild + republish
#   the bundle. Set BUNDLE_URL + BUNDLE_PASSWORD.
#
# MODE B (RAW FILES): curl each file from raw.githubusercontent.com. Set GIT_RAW_URL.
#   Used only if BUNDLE_URL is empty.
#
# ---- MODE A: bundle (encrypted OR plain) ----
# Public raw URL to the bundle. Two forms:
#   encrypted (.enc): set BUNDLE_PASSWORD too (openssl aes-256-cbc, pbkdf2, iter 200000)
#   plain (.tar.gz):  leave BUNDLE_PASSWORD empty  <-- quick-test path
# NOTE: use the RAW url (raw.githubusercontent.com/.../main/file), NOT the /blob/ page URL.
BUNDLE_URL="https://raw.githubusercontent.com/jerem-nuta/registry-web/main/nkp-lab-bundle.tar.gz"
BUNDLE_PASSWORD=""     # empty = plain tar.gz (no decrypt). set it for an .enc bundle.
# subdir INSIDE the bundle that holds the web pages + downloader-backend/
BUNDLE_WEB_SUBDIR="nkp-lab-bundle/registry-web"
#
# ---- MODE B: raw files (fallback if BUNDLE_URL empty) ----
# GitHub (public):  https://raw.githubusercontent.com/<user>/<repo>/<branch>
# GitHub (private): same URL, set GIT_TOKEN to a fine-grained PAT with read access
# Gitea (internal): https://gitea.<domain>/<user>/<repo>/raw/branch/<branch>
GIT_RAW_URL="https://raw.githubusercontent.com/jerem-nuta/registry-web/main"
GIT_TOKEN=""    # leave empty for public; set a PAT/token if the repo is private
# backend source dir within the repo (app.py, page.html, Dockerfile)
GIT_BACKEND_PATH="downloader-backend"
# =================================================================
# NKP mirror projects are derived per-version in the project-creation block below.
# helper: "2.17.1" -> "nkp-2-17-1"
nkp_proj() { echo "nkp-$(echo "$1" | tr '.' '-')"; }

# keep harbor.yml admin password in sync with CRED SET 1
sed -i "s/^harbor_admin_password:.*/harbor_admin_password: ${HARBOR_ADMIN_PASSWORD}/" /opt/harbor/harbor.yml

# generate the file-server htpasswd from CRED SET 3 (single source of truth)
dnf -y install httpd-tools 2>/dev/null || true
# generate a random file-server password if requested
if [ "${FILES_PASSWORD}" = "GENERATE" ] || [ -z "${FILES_PASSWORD}" ]; then
  FILES_PASSWORD="$(openssl rand -base64 12 | tr -d '/+=' | head -c 16)"
fi
echo "${FILES_PASSWORD}" > /opt/harbor/files-password.txt; chmod 0600 /opt/harbor/files-password.txt
htpasswd -bc /etc/nginx/nkp-files.htpasswd "${FILES_USER}" "${FILES_PASSWORD}"
chmod 0644 /etc/nginx/nkp-files.htpasswd

dnf -y install dnf-plugins-core "kernel-modules-extra-$(uname -r)" git tmux curl jq openssl nginx \
  || dnf -y install dnf-plugins-core kernel-modules-extra git tmux curl jq openssl nginx
modprobe br_netfilter || true
modprobe overlay      || true
dnf -y install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
systemctl enable --now docker
usermod -aG docker harbor   || true
usermod -aG docker sysadmin || true
update-ca-trust extract

# guard: refuse to deploy Harbor if the cert/key are still placeholders
if grep -q "REPLACE_WITH_REGISTRY" /opt/harbor/certs/registry.crt /opt/harbor/certs/registry.key 2>/dev/null; then
  echo "TLS cert/key are placeholders. Put the real registry cert+key in /opt/harbor/certs/ then: sudo rm -f /var/lib/harbor-install.done; sudo /opt/harbor/install-harbor.sh" >&2
  exit 0
fi
# fullchain Harbor + nginx serve = leaf + issuing CA
cat /opt/harbor/certs/registry.crt /etc/pki/ca-trust/source/anchors/issuingca.crt \
  > /opt/harbor/certs/registry-fullchain.crt
chmod 0644 /opt/harbor/certs/registry-fullchain.crt

# --- Harbor ---
cd /opt/harbor
OFFLINE=$(ls -1 /opt/harbor/harbor-offline-installer-*.tgz 2>/dev/null | head -1 || true)
if [ -n "$OFFLINE" ]; then tar xzf "$OFFLINE"
else
  curl -fLO "https://github.com/goharbor/harbor/releases/download/${HARBOR_VERSION}/harbor-online-installer-${HARBOR_VERSION}.tgz"
  tar xzf "harbor-online-installer-${HARBOR_VERSION}.tgz"
fi
cp -f /opt/harbor/harbor.yml /opt/harbor/harbor/harbor.yml
cd /opt/harbor/harbor
./install.sh --with-trivy

# --- apply the NKP lab theme to the Harbor UI ---
# The portal container serves the Angular app; inject our stylesheet into index.html.
PORTAL=$(docker ps --format '{{.Names}}' | grep -E 'harbor-portal|nginx' | head -1 || true)
if [ -n "$PORTAL" ]; then
  docker cp /opt/harbor/theme/nkp-theme.css "${PORTAL}:/usr/share/nginx/html/nkp-theme.css" 2>/dev/null \
    || docker cp /opt/harbor/theme/nkp-theme.css "${PORTAL}:/usr/share/nginx/html/" 2>/dev/null || true
  # inject the <link> before </head> if not already present
  docker exec "$PORTAL" sh -c '
    F=/usr/share/nginx/html/index.html
    if [ -f "$F" ] && ! grep -q nkp-theme.css "$F"; then
      sed -i "s#</head>#<link rel=\"stylesheet\" href=\"/nkp-theme.css\"></head>#" "$F"
    fi
  ' 2>/dev/null || true
fi
# persist the theme across restarts: mount it via a compose override
cat > /opt/harbor/harbor/docker-compose.override.yml <<'OVR'
services:
  portal:
    volumes:
      - /opt/harbor/theme/nkp-theme.css:/usr/share/nginx/html/nkp-theme.css:ro
OVR
# re-inject after any restart via a tiny oneshot
cat > /usr/local/bin/harbor-theme-inject.sh <<'INJ'
#!/usr/bin/env bash
P=$(docker ps --format '{{.Names}}' | grep -E 'harbor-portal|nginx' | head -1)
[ -z "$P" ] && exit 0
docker exec "$P" sh -c '
  F=/usr/share/nginx/html/index.html
  if [ -f "$F" ] && ! grep -q nkp-theme.css "$F"; then
    sed -i "s#</head>#<link rel=\"stylesheet\" href=\"/nkp-theme.css\"></head>#" "$F"
  fi'
INJ
chmod +x /usr/local/bin/harbor-theme-inject.sh
cat > /etc/systemd/system/harbor-theme.service <<'SVC'
[Unit]
Description=Re-inject NKP theme into Harbor portal after restart
After=docker.service
Requires=docker.service
[Service]
Type=oneshot
ExecStart=/usr/local/bin/harbor-theme-inject.sh
[Install]
WantedBy=multi-user.target
SVC
systemctl daemon-reload && systemctl enable harbor-theme.service || true

# --- remove old/unused kernels (keep running + newest) ---
dnf -y install dnf-plugins-core || true
# keep at most 2 kernels going forward
sed -i 's/^installonly_limit=.*/installonly_limit=2/' /etc/dnf/dnf.conf 2>/dev/null || echo 'installonly_limit=2' >> /etc/dnf/dnf.conf
# prune all but the most recent, protecting the running kernel
dnf -y remove $(dnf repoquery --installonly --latest-limit=-1 -q 2>/dev/null | grep -v "$(uname -r)" || true) 2>/dev/null || true
dnf -y autoremove || true

# --- nginx portal + file server (8080) ---
mkdir -p /data/nkp-sources
# strip nginx's default port-80 server (collides with Harbor on :80)
cp /etc/nginx/nginx.conf /etc/nginx/nginx.conf.orig 2>/dev/null || true
awk '
  /^[[:space:]]*server[[:space:]]*\{/ { buf=$0"\n"; depth=1; inblk=1; has80=0; next }
  inblk {
    buf=buf $0 "\n"
    n=gsub(/\{/,"{"); depth+=n
    m=gsub(/\}/,"}"); depth-=m
    if ($0 ~ /listen[[:space:]]+(\[::\]:)?80([[:space:];])/) has80=1
    if (depth<=0) { if (!has80) printf "%s", buf; inblk=0; buf="" }
    next
  }
  { print }
' /etc/nginx/nginx.conf > /etc/nginx/nginx.conf.new && mv /etc/nginx/nginx.conf.new /etc/nginx/nginx.conf
# SELinux: port label for 8080, and content label for BOTH webroot and htpasswd
setsebool -P httpd_read_user_content 1 || true
semanage port -a -t http_port_t -p tcp 8080 2>/dev/null || semanage port -m -t http_port_t -p tcp 8080 2>/dev/null || true
semanage fcontext -a -t httpd_sys_content_t "/data/nkp-sources(/.*)?" 2>/dev/null || true
restorecon -Rv /data/nkp-sources || true
nginx -t && systemctl enable --now nginx || systemctl restart nginx || true
# if SSO is enabled AND Authentik is reachable, flip the portal to forward-auth
if [ "${SSO_ENABLED}" = "true" ]; then
  /usr/local/bin/sso-toggle.sh on "${AUTHENTIK_HOST}" || \
    echo "SSO requested but toggle failed (Authentik not up yet?) — portal stays on basic auth; run sso-toggle.sh on later"
fi
firewall-cmd --permanent --add-port=8080/tcp 2>/dev/null || true

# === fetch the bundle ONCE (MODE A): download, decrypt if needed, unpack ===
BUNDLE_STAGE=""
if [ -n "${BUNDLE_URL}" ]; then
  echo "fetching bundle: ${BUNDLE_URL}"
  if curl -fsSL "${BUNDLE_URL}" -o /tmp/nkp-bundle.dl; then
    BUNDLE_OK=1
    if [ -n "${BUNDLE_PASSWORD}" ]; then
      # encrypted: decrypt to the tar.gz
      if openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 \
           -in /tmp/nkp-bundle.dl -out /tmp/nkp-bundle.tar.gz \
           -pass pass:"${BUNDLE_PASSWORD}" 2>/dev/null; then
        :
      else
        echo "bundle: decrypt FAILED (wrong BUNDLE_PASSWORD?) — falling back to raw fetch" >&2
        BUNDLE_OK=0
      fi
    else
      # plain tar.gz: use as-is (quick-test path)
      mv /tmp/nkp-bundle.dl /tmp/nkp-bundle.tar.gz
    fi
    if [ "${BUNDLE_OK}" = "1" ]; then
      mkdir -p /opt/harbor/bundle
      if tar xzf /tmp/nkp-bundle.tar.gz -C /opt/harbor/bundle 2>/dev/null; then
        BUNDLE_STAGE="/opt/harbor/bundle/${BUNDLE_WEB_SUBDIR}"
        echo "bundle unpacked -> ${BUNDLE_STAGE}"
      else
        echo "bundle: tar extract failed (got HTML instead of tar? check RAW url) — falling back to raw fetch" >&2
      fi
    fi
    rm -f /tmp/nkp-bundle.dl /tmp/nkp-bundle.tar.gz
  else
    echo "bundle: download failed from ${BUNDLE_URL} — falling back to raw fetch" >&2
  fi
fi

# --- one-click downloader + PC backend (port 8445, HTTPS) ---
mkdir -p /opt/harbor/downloader
if [ -n "${BUNDLE_STAGE}" ] && [ -d "${BUNDLE_STAGE}/downloader-backend" ]; then
  # MODE A: copy backend out of the unpacked bundle
  cp "${BUNDLE_STAGE}/downloader-backend/app.py" \
     "${BUNDLE_STAGE}/downloader-backend/page.html" \
     "${BUNDLE_STAGE}/downloader-backend/Dockerfile" /opt/harbor/downloader/ 2>/dev/null || true
  echo "backend staged from bundle"
else
  # MODE B: fetch each backend file from raw git
  GH_HDR=()
  [ -n "${GIT_TOKEN}" ] && GH_HDR=(-H "Authorization: token ${GIT_TOKEN}")
  for f in app.py page.html Dockerfile; do
    curl -fsSL "${GH_HDR[@]}" "${GIT_RAW_URL%/}/${GIT_BACKEND_PATH}/${f}" -o "/opt/harbor/downloader/${f}" || true
  done
fi
cat > /opt/harbor/downloader/docker-compose.yml <<DLC
services:
  nkp-downloader:
    build: /opt/harbor/downloader
    image: nkp-downloader:local
    container_name: nkp-downloader
    restart: unless-stopped
    ports:
      - "8445:8445"
    environment:
      NKP_DEST: /data/nkp-sources
      NKP_DL_PORT: "8445"
      NKP_DL_USER: "${FILES_USER}"
      NKP_DL_PASS: "${FILES_PASSWORD}"
      NKP_TLS_CERT: /certs/registry-fullchain.crt
      NKP_TLS_KEY: /certs/registry.key
    volumes:
      - /data/nkp-sources:/data/nkp-sources
      - /opt/harbor/certs:/certs:ro
DLC
if [ -s /opt/harbor/downloader/app.py ]; then
  (cd /opt/harbor/downloader && docker compose up -d --build) || true
  firewall-cmd --permanent --add-port=8445/tcp 2>/dev/null || true
  firewall-cmd --reload 2>/dev/null || true
else
  echo "downloader backend not fetched (check GIT_RAW_URL/${GIT_BACKEND_PATH}); skipping" >&2
fi

# --- Authentik SSO stack (server+worker+postgres+redis), reusing the registry cert ---
if [ "${DEPLOY_AUTHENTIK}" = "true" ]; then
  echo "===== AUTHENTIK: DEPLOY_AUTHENTIK=true — deploying SSO stack ====="
  # wait until Harbor can actually serve image pulls (avoids cold-boot race)
  echo "AUTHENTIK: waiting for Harbor to be pullable..."
  for i in $(seq 1 30); do
    curl -fsSk -u "admin:${HARBOR_ADMIN_PASSWORD}" "https://${FQDN}/api/v2.0/health" >/dev/null 2>&1 && break
    sleep 5
  done
  echo "deploying Authentik (reusing registry cert on :9443)"
  mkdir -p /opt/authentik/certs
  # reuse the embedded registry cert + CA chain that Harbor already uses
  cp /opt/harbor/certs/registry-fullchain.crt /opt/authentik/certs/authentik-fullchain.crt 2>/dev/null || true
  cp /opt/harbor/certs/registry.key           /opt/authentik/certs/authentik.key           2>/dev/null || true
  cp /opt/harbor/certs/registry-ca-chain.crt  /opt/authentik/certs/ca-chain.crt             2>/dev/null || true
  # secrets
  AK_PG_PASS="$(openssl rand -base64 36 | tr -d '/+=')"
  AK_SECRET="$(openssl rand -base64 60 | tr -d '/+=')"
  cat > /opt/authentik/.env <<AKENV
PG_USER=authentik
PG_DB=authentik
PG_PASS=${AK_PG_PASS}
AUTHENTIK_SECRET_KEY=${AK_SECRET}
AUTHENTIK_TAG=${AUTHENTIK_TAG}
AKENV
  cat > /opt/authentik/docker-compose.yml <<AKCOMPOSE
services:
  postgresql:
    image: ${AUTHENTIK_PG_IMAGE}
    restart: unless-stopped
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -d authentik -U authentik"]
      start_period: 20s
      interval: 30s
      retries: 5
      timeout: 5s
    volumes:
      - database:/var/lib/postgresql/data
    environment:
      POSTGRES_PASSWORD: ${AK_PG_PASS}
      POSTGRES_USER: authentik
      POSTGRES_DB: authentik
  redis:
    image: ${AUTHENTIK_REDIS_IMAGE}
    command: --save 60 1 --loglevel warning
    restart: unless-stopped
    volumes:
      - redis:/data
  server:
    image: ${AUTHENTIK_IMAGE}:${AUTHENTIK_TAG}
    restart: unless-stopped
    command: server
    environment:
      AUTHENTIK_SECRET_KEY: ${AK_SECRET}
      AUTHENTIK_REDIS__HOST: redis
      AUTHENTIK_POSTGRESQL__HOST: postgresql
      AUTHENTIK_POSTGRESQL__USER: authentik
      AUTHENTIK_POSTGRESQL__NAME: authentik
      AUTHENTIK_POSTGRESQL__PASSWORD: ${AK_PG_PASS}
      AUTHENTIK_DISABLE_STARTUP_ANALYTICS: "true"
      AUTHENTIK_ERROR_REPORTING__ENABLED: "false"
    volumes:
      - media:/media
      - /opt/authentik/certs:/certs:ro
    ports:
      - "9000:9000"
      - "9443:9443"
    depends_on: [postgresql, redis]
  worker:
    image: ${AUTHENTIK_IMAGE}:${AUTHENTIK_TAG}
    restart: unless-stopped
    command: worker
    user: root
    environment:
      AUTHENTIK_SECRET_KEY: ${AK_SECRET}
      AUTHENTIK_REDIS__HOST: redis
      AUTHENTIK_POSTGRESQL__HOST: postgresql
      AUTHENTIK_POSTGRESQL__USER: authentik
      AUTHENTIK_POSTGRESQL__NAME: authentik
      AUTHENTIK_POSTGRESQL__PASSWORD: ${AK_PG_PASS}
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock
      - media:/media
      # worker chowns /certs on startup — must be writable (NOT :ro, or it crash-loops)
      - /opt/authentik/certs:/certs
    depends_on: [postgresql, redis]
volumes:
  database:
  redis:
  media:
AKCOMPOSE
  (cd /opt/authentik && docker compose up -d) || echo "authentik compose up failed (images in Harbor? DMZ reachable?)" >&2
  for p in 9000 9443; do firewall-cmd --permanent --add-port=${p}/tcp 2>/dev/null || true; done
  firewall-cmd --reload 2>/dev/null || true
  echo "Authentik starting — finish setup at https://registry.emeagso2026.local:9443/if/flow/initial-setup/"
else
  echo "===== AUTHENTIK: DEPLOY_AUTHENTIK=false — skipping SSO stack (set true to deploy) ====="
fi


# --- stage the portal pages: from the unpacked bundle (MODE A) or raw git (MODE B) ---
if [ -n "${BUNDLE_STAGE}" ] && [ -d "${BUNDLE_STAGE}" ]; then
  # copy every web asset shipped in the bundle's registry-web/ root
  for f in index.html nkp-stack.html nkp-checklist.html nkp-env-builder.html nkp-downloader.html versions.json; do
    [ -f "${BUNDLE_STAGE}/${f}" ] && cp "${BUNDLE_STAGE}/${f}" "/data/nkp-sources/${f}" || true
  done
  echo "portal pages staged from bundle"
  restorecon -Rv /data/nkp-sources || true
elif [ -n "${GIT_RAW_URL}" ]; then
  GH_HDR=()
  [ -n "${GIT_TOKEN}" ] && GH_HDR=(-H "Authorization: token ${GIT_TOKEN}")
  for f in index.html nkp-stack.html nkp-checklist.html nkp-env-builder.html nkp-downloader.html versions.json; do
    curl -fsSL "${GH_HDR[@]}" "${GIT_RAW_URL%/}/${f}" -o "/data/nkp-sources/${f}" || true
  done
  restorecon -Rv /data/nkp-sources || true
fi

firewall-cmd --reload 2>/dev/null || true

# --- NFS server: export /data/nkp-sources to the bastion (rw) ---
dnf -y install nfs-utils || true
mkdir -p /data/nkp-sources /etc/exports.d
chmod 0775 /data/nkp-sources
# one export entry per allowed bastion IP
: > /etc/exports.d/nkp-sources.exports
for BIP in ${BASTION_IPS}; do
  echo "/data/nkp-sources ${BIP}(rw,sync,no_subtree_check,no_root_squash)" \
    >> /etc/exports.d/nkp-sources.exports
done
systemctl enable --now nfs-server rpcbind || true
exportfs -ra || true

# --- stage bastion helper files into the web-served dir (HTTP-grabbable) ---
# stage versions.json (single source of truth for versions) if not already present
if [ ! -f /data/nkp-sources/versions.json ]; then
  cat > /data/nkp-sources/versions.json <<'VJSON'
{
  "versions": [
    { "version": "2.17.0", "k8s": "1.34.3", "default": false },
    { "version": "2.17.1", "k8s": "1.34.3", "default": true  },
    { "version": "2.18.0", "k8s": "1.35.0", "default": false },
    { "version": "2.18.1", "k8s": "1.35.0", "default": false }
  ]
}
VJSON
fi

cat > /data/nkp-sources/bastion-mount-nkp-sources.sh <<'BMOUNT'
#!/usr/bin/env bash
set -euo pipefail
NFS_SERVER_IP="__SRVIP__"
NFS_EXPORT="/data/nkp-sources"
MOUNT_POINT="/mnt/nkp-sources"
command -v dnf >/dev/null && sudo dnf -y install nfs-utils
sudo mkdir -p "$MOUNT_POINT"
sudo mount -t nfs "${NFS_SERVER_IP}:${NFS_EXPORT}" "$MOUNT_POINT"
LINE="${NFS_SERVER_IP}:${NFS_EXPORT}  ${MOUNT_POINT}  nfs  rw,_netdev,noauto,x-systemd.automount  0  0"
grep -qF "${NFS_SERVER_IP}:${NFS_EXPORT}" /etc/fstab || echo "$LINE" | sudo tee -a /etc/fstab
sudo systemctl daemon-reload
echo "Mounted ${NFS_SERVER_IP}:${NFS_EXPORT} -> ${MOUNT_POINT}"
BMOUNT
sed -i "s/__SRVIP__/$(hostname -I | awk '{print $1}')/" /data/nkp-sources/bastion-mount-nkp-sources.sh
chmod 0644 /data/nkp-sources/bastion-mount-nkp-sources.sh

# firewall: allow NFS only from the bastion IP
firewall-cmd --permanent --add-service=nfs  2>/dev/null || true
firewall-cmd --permanent --add-service=rpc-bind 2>/dev/null || true
firewall-cmd --permanent --add-service=mountd 2>/dev/null || true
firewall-cmd --reload 2>/dev/null || true

# --- Harbor projects: dockerhub proxy cache + version-named NKP mirror ---
ADMIN_PW="${HARBOR_ADMIN_PASSWORD}"
API="https://${FQDN}/api/v2.0"
AUTH=(-u "admin:${ADMIN_PW}")
for i in $(seq 1 40); do curl -fsS "${AUTH[@]}" "${API}/health" >/dev/null 2>&1 && break || sleep 5; done

if [ -n "${DOCKERHUB_USER}" ] && [ -n "${DOCKERHUB_TOKEN}" ]; then
  EP_CRED="\"credential\":{\"type\":\"basic\",\"access_key\":\"${DOCKERHUB_USER}\",\"access_secret\":\"${DOCKERHUB_TOKEN}\"},"
else
  EP_CRED=""
fi
curl -fsS "${AUTH[@]}" -X POST "${API}/registries" -H "Content-Type: application/json" \
  -d "{\"name\":\"dockerhub\",\"type\":\"docker-hub\",\"url\":\"https://hub.docker.com\",${EP_CRED}\"insecure\":false}" || true
EP_ID=$(curl -fsS "${AUTH[@]}" "${API}/registries?name=dockerhub" | jq -r '.[0].id')
curl -fsS "${AUTH[@]}" -X POST "${API}/projects" -H "Content-Type: application/json" \
  -d "{\"project_name\":\"dockerhub\",\"registry_id\":${EP_ID},\"metadata\":{\"public\":\"true\"}}" || true
# GHCR pull-through cache (for authentik + other ghcr.io images). Works when
# Harbor has outbound internet (DMZ). Harmless if it can't reach ghcr.
curl -fsS "${AUTH[@]}" -X POST "${API}/registries" -H "Content-Type: application/json" \
  -d "{\"name\":\"ghcr\",\"type\":\"github-ghcr\",\"url\":\"https://ghcr.io\",\"insecure\":false}" || true
GHCR_ID=$(curl -fsS "${AUTH[@]}" "${API}/registries?name=ghcr" | jq -r '.[0].id')
if [ -n "${GHCR_ID}" ] && [ "${GHCR_ID}" != "null" ]; then
  curl -fsS "${AUTH[@]}" -X POST "${API}/projects" -H "Content-Type: application/json" \
    -d "{\"project_name\":\"ghcr\",\"registry_id\":${GHCR_ID},\"metadata\":{\"public\":\"true\"}}" || true
fi
# authentik SSO project (for pushed/cached authentik images)
curl -fsS "${AUTH[@]}" -X POST "${API}/projects" -H "Content-Type: application/json" \
  -d "{\"project_name\":\"authentik\",\"metadata\":{\"public\":\"false\"}}" || true
# one private mirror project per NKP version, plus its source folder
for V in ${NKP_VERSIONS}; do
  P="$(nkp_proj "$V")"
  curl -fsS "${AUTH[@]}" -X POST "${API}/projects" -H "Content-Type: application/json" \
    -d "{\"project_name\":\"${P}\",\"metadata\":{\"public\":\"false\"}}" || true
  mkdir -p "/data/nkp-sources/nkp-v${V}"
done

# --- write a credentials summary MOTD from the REAL values ---
FILES_PW_REAL="$(cat /opt/harbor/files-password.txt 2>/dev/null || echo "${FILES_PASSWORD}")"
NKP_PROJECTS_LIST="$(for V in ${NKP_VERSIONS}; do nkp_proj "$V"; done | paste -sd, -)"
ADMIN_PW_REAL="$(awk '/harbor_admin_password:/{print $2}' /opt/harbor/harbor.yml 2>/dev/null || echo "${HARBOR_ADMIN_PASSWORD}")"
cat > /etc/motd.d/00-nkp-setup <<MOTD

============================================================
  NKP Harbor host — READY
------------------------------------------------------------
  Registry UI : https://${FQDN}
  Portal      : https://${FQDN}:8080/
  Downloader  : http://${FQDN}:8445/
  Projects    : dockerhub (cache) + ${NKP_PROJECTS_LIST}
------------------------------------------------------------
  LOGINS
    OS (ssh)     : harbor / (set in cloud-init)
    Harbor admin : admin / ${ADMIN_PW_REAL}
    Portal (8080): ${FILES_USER} / ${FILES_PW_REAL}
    Downloader   : ${FILES_USER} / ${FILES_PW_REAL}  (port 8445)
  (file-server password also in /opt/harbor/files-password.txt)
============================================================

MOTD
touch "$MARKER"
wall "Harbor up as ${FQDN}. Registry: https://${FQDN}  Projects: dockerhub (cache), ${NKP_PROJECTS_LIST}. Portal: https://${FQDN}:8080/  Change admin password on first UI login."

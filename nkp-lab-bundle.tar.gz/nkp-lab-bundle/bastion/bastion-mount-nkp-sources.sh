#!/usr/bin/env bash
# Mount Harbor's /data/nkp-sources on the bastion (read-write) and persist it.
# Run on the BASTION with sudo.
set -euo pipefail

NFS_SERVER_IP="10.68.24.103"          # Harbor host
NFS_EXPORT="/data/nkp-sources"
MOUNT_POINT="/mnt/nkp-sources"

# 1) NFS client tools
if command -v dnf >/dev/null; then
  sudo dnf -y install nfs-utils
fi

# 2) mount point
sudo mkdir -p "$MOUNT_POINT"

# 3) test mount now
sudo mount -t nfs "${NFS_SERVER_IP}:${NFS_EXPORT}" "$MOUNT_POINT"
echo "Mounted ${NFS_SERVER_IP}:${NFS_EXPORT} -> ${MOUNT_POINT}"
ls -la "$MOUNT_POINT"

# 4) persist across reboots via /etc/fstab (idempotent)
FSTAB_LINE="${NFS_SERVER_IP}:${NFS_EXPORT}  ${MOUNT_POINT}  nfs  rw,_netdev,noauto,x-systemd.automount  0  0"
if ! grep -qF "${NFS_SERVER_IP}:${NFS_EXPORT}" /etc/fstab; then
  echo "$FSTAB_LINE" | sudo tee -a /etc/fstab
  sudo systemctl daemon-reload
fi
echo "Persisted in /etc/fstab (systemd automount)."
echo "Source the env with:  set -a; source ${MOUNT_POINT}/nkp-deploy.env; set +a"

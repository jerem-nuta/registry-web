# Prism Central Service Account for NKP — Setup Guide

> Note: the env-builder portal queries Prism Central using the **v4 APIs** (clustermgmt / networking / vmm namespaces). The service account below needs read access to clusters, subnets, and images; NKP/CAPX itself needs VM lifecycle permissions.

Create a **dedicated, least-privilege service account** in Prism Central for NKP, instead of
using `admin`. This limits the blast radius if the credential (which lives in `nkp-deploy.env`)
is ever exposed.

---

## Why

- `nkp-deploy.env` must contain `NUTANIX_USER` + `NUTANIX_PASSWORD` (NKP reads them at
  `nkp create cluster` time and CAPX stores them as a Secret for ongoing reconciliation).
- That file is therefore a **secret**: keep it mode `600`, never commit it to git.
- Using a scoped service account (not `admin`) means a leaked credential can only perform
  NKP-related infra operations — not full Prism Central administration.

---

## What NKP / CAPX does with the account

The Cluster API provider for Nutanix (CAPX) uses this account to, continuously:
- create / delete / power VMs (control-plane + worker nodes)
- attach the chosen **VM image** (the NKP OS image you uploaded)
- place VMs on the chosen **subnet** and **Prism Element cluster**
- provision storage via the CSI **storage container**
- read categories / projects / clusters / subnets / images for placement

So the role must allow VM lifecycle + read of images, subnets, clusters, projects, and storage.

---

## Step 1 — Create a custom Role (Prism Central)

Prism Central → **Admin Center → Roles → Create Role**. Name it e.g. `nkp-operator`.

Grant these permission areas (entity : access). **Verify the exact list against the official
NKP 2.17 doc** — *Prism Central Roles and Permissions* — as the precise permission names can
change between versions:
`portal.nutanix.com → Nutanix Kubernetes Platform v2.17 → Prism Central Role Permissions`

Typical required permissions:

| Entity | Access needed |
|--------|---------------|
| VM | Create, Update, Delete, View (full VM lifecycle) |
| Image | View (attach the NKP OS image) |
| Subnet | View (place nodes on the subnet) |
| Cluster (Prism Element) | View |
| Storage Container | View (CSI provisioning target) |
| Category | View, Assign (CAPX tags nodes with categories) |
| Project | View |
| Marketplace / App | (only if deploying via Marketplace UI) |

> NOTE: This table is a **synthesized** best-practice list based on what CAPX does, not a
> verbatim copy of the Nutanix permission matrix. Before relying on it, open the official
> "Prism Central Role Permissions" page for NKP 2.17 and match the exact permission names —
> Nutanix lists them explicitly there. If a deploy fails with a 403, the missing permission
> name will be in the CAPX controller logs; add it to the role.

---

## Step 2 — Create the service user

Prism Central → **Admin Center → Users → Add User** (local), e.g.:
- Username: `nkp-svc@emeagso2026.local` (or a local user `nkp-svc`)
- Set a strong password

If you use AD/LDAP instead, create the account there and reference it.

---

## Step 3 — Assign the role to the user (scoped)

Prism Central → **Admin Center → Roles → nkp-operator → Manage Assignment** (or
**Authorization Policies** on newer PC). Assign the `nkp-operator` role to `nkp-svc`,
scoped to the **project / categories** NKP will use if you want to constrain it further.

---

## Step 4 — Put it in nkp-deploy.env

Use the env builder (or edit by hand):
```
NUTANIX_USER=nkp-svc@emeagso2026.local
NUTANIX_PASSWORD=<the service account password>
NUTANIX_ENDPOINT=10.68.24.x      # or pc.emeagso2026.local
NUTANIX_PORT=9440
```
Then lock the file down:
```bash
chmod 600 nkp-deploy.env
```
**Never commit this file.** Confirm it's in `.gitignore`.

---

## Step 5 — Verify with the env builder's "Connect to PC"

In `nkp-env-builder.html`, enter the service account's PC IP / user / password and click
**Connect to PC**. If the role is correct, the **images** and **subnets** dropdowns populate.
If you get "auth failed", the credential is wrong; if you connect but lists are empty, the
role is missing **Image View** / **Subnet View**.

---

## Rotating the credential

If the password is ever exposed:
1. Reset the service account password in Prism Central.
2. Update `NUTANIX_PASSWORD` in `nkp-deploy.env`.
3. For a running cluster, update the CAPX credential Secret (so reconciliation keeps working) —
   see the NKP docs for "update Nutanix credentials".

Because the account is scoped, a leaked credential can't be used for general PC administration —
which is the whole point of not using `admin`.

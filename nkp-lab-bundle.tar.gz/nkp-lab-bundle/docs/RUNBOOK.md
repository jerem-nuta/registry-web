# NKP Lab — Harbor + Bastion Deployment Runbook

A single, ordered guide. Follow top to bottom. Each step says **what to do** and **how to check it worked** before moving on.

- **Harbor host:** `registry.emeagso2026.local` = `10.68.24.103`
- **Bastion:** `nkp-bastion` = `10.68.24.102`
- **Logins (lab defaults):**
  - Harbor UI: `admin` / `Harbor12345`
  - Portal (8080) + downloader (8445): `admin` / `Harbor12345`
  - OS (Harbor): `harbor` / `harbor/4u` · OS (bastion): `nutanix` / `nutanix/4u`

---

## Part 1 — Deploy Harbor (Task 1)

### 1.1 Create the VM in Prism Central
- Rocky Linux 10 cloud image, **UEFI** boot, host-passthrough CPU.
- 4 vCPU / 16 GB RAM / 128 GB disk.
- Name the VM `registry`, put it on the IPAM subnet, give it `10.68.24.103`.
- **Custom script (cloud-init):** paste the contents of **`cloud-init-harbor.yml`**.
  - Confirm the header line reads `Harbor registry host` — not the bastion file.

### 1.2 Let it run
The VM boots, updates the kernel, **reboots once**, then installs Docker + Harbor + the file server. This takes ~10–15 min.

**Check progress** (SSH in as `harbor`):
```bash
sudo cloud-init status --long          # want: status: done
journalctl -u harbor-install -f        # live install log; Ctrl-C to stop watching
```
The login banner shows `SETUP IN PROGRESS` until it finishes, then switches to `READY`.

### 1.3 Confirm Harbor is up
```bash
cd /opt/harbor/harbor && sudo docker compose ps      # all containers Up/healthy
curl -sk https://10.68.24.103/api/v2.0/health        # expect: {"status":"healthy"...}
```
Open `https://registry.emeagso2026.local` in a browser → log in `admin` / `Harbor12345`.
You should see two projects: **`dockerhub`** (proxy cache) and **`nkp-2-17-0`** (mirror).

> If a container is missing or Harbor errored, see **Troubleshooting → Harbor** below.

---

## Part 2 — Web services (file server + upload portal)

These come up automatically with the cloud-init above. Verify them.

### 2.1 Portal (port 8080, nginx — download/browse)
```bash
curl -skI -u admin:Harbor12345 https://10.68.24.103:8080/      # expect: HTTP/1.1 200
```
Browser: `https://10.68.24.103:8080/` → login `admin` / `Harbor12345` → directory listing.

### 2.2 Downloader (port 8445, HTTPS — stage bundles from Nutanix links) — OPTIONAL
```bash
curl -sk https://10.68.24.103:8445/      # expect the downloader page (or 401 asking auth)
```
Browser: `https://10.68.24.103:8445/` → login `admin` / `Harbor12345`.

> The downloader (8445) is a **convenience for staging bundles** — paste a Nutanix signed URL and it fetches the file straight into `/data/nkp-sources/`. You can always use `scp` instead (Part 3, Option B). It shares the `admin` / `Harbor12345` login and serves over HTTPS with the registry cert. It also powers the env-builder's "Connect to PC" cascade via the v4 API (clusters → subnets → images).

---

## Part 3 — Upload the portal pages

The web server is built; the portal HTML is **content you add**.

### Option A — drag-and-drop (easiest)
Open the upload portal `https://10.68.24.103:8445/`, drag in:
- `index.html`
- `nkp-env-builder.html`

### Option B — scp (reliable)
```bash
# from your workstation where the files are saved:
scp index.html nkp-env-builder.html harbor@10.68.24.103:/tmp/
# then on Harbor:
sudo cp /tmp/index.html /tmp/nkp-env-builder.html /data/nkp-sources/
```

### 3.1 Confirm the portal loads
```bash
curl -skI -u admin:Harbor12345 https://10.68.24.103:8080/index.html   # expect 200
```
Browser: `https://10.68.24.103:8080/index.html` → the lab portal with the architecture diagram, links to the env builder, Harbor, Prism Central, and docs.

---

## Part 4 — Stage the NKP source bundles

Download these from the Nutanix Support Portal, then upload them to `/data/nkp-sources/`
(via the upload portal or scp, same as Part 3):
- `nkp_v2.17.0_linux_amd64.tar.gz` (the CLI)
- `konvoy-image-bundle-v2.17.0.tar`
- `kommander-image-bundle-v2.17.0.tar`
- `nkp-catalog-applications-image-bundle-v2.17.0.tar`

**Check they're there:**
```bash
ls -lh /data/nkp-sources/
```

---

## Part 5 — Build the deploy env file

Open the env builder in a browser: `https://10.68.24.103:8080/nkp-env-builder.html`
Fill in the fields → it generates **`nkp-deploy.env`** → download it → upload it to `/data/nkp-sources/`.

(Or edit the sample `nkp-deploy.env` by hand and place it there.)

---

## Part 6 — Deploy the bastion (Task 2)

### 6.1 Create the VM in Prism Central
- Rocky Linux 10, UEFI, host-passthrough CPU. 4 vCPU / 16 GB / 128 GB.
- Name `nkp-bastion`, IP `10.68.24.102` (must match the `BASTION_IP` in the Harbor cloud-init).
- **Custom script:** paste **`bastion-cloud-init-task2.yml`**.

### 6.2 Let it run
Reboots once, installs Docker/kubectl/helm, grabs the mount helper from Harbor, mounts the NFS share.

**Check** (SSH in as `nutanix`):
```bash
sudo cloud-init status --long
journalctl -u bastion-install -f
```

### 6.3 Confirm the NFS mount
```bash
ls -la /mnt/nkp-sources/        # should show the same files as Harbor's /data/nkp-sources
mount | grep nkp-sources        # confirms the NFS mount is active
```

### 6.4 Load the env
```bash
set -a; source /mnt/nkp-sources/nkp-deploy.env; set +a
echo $REGISTRY_MIRROR_URL       # sanity check a variable resolved
```

---

## Part 7 — Push bundles + create the cluster

On the bastion, with the env loaded:
```bash
# extract the CLI
tar xzf /mnt/nkp-sources/nkp_v2.17.0_linux_amd64.tar.gz
sudo install -m0755 nkp /usr/local/bin/nkp
nkp version

# log in to Harbor and push the image bundles into the mirror project
docker login registry.emeagso2026.local -u admin
nkp push bundle --bundle /mnt/nkp-sources/konvoy-image-bundle-v2.17.0.tar \
  --to-registry=${REGISTRY_MIRROR_URL}
nkp push bundle --bundle /mnt/nkp-sources/kommander-image-bundle-v2.17.0.tar \
  --to-registry=${REGISTRY_MIRROR_URL}

# create the air-gapped management cluster (adjust flags to your env)
nkp create cluster nutanix \
  --cluster-name ${CLUSTER_NAME} \
  --airgapped \
  --registry-mirror-url=${REGISTRY_MIRROR_URL} \
  --registry-mirror-username=admin \
  --registry-mirror-password=${REGISTRY_PASSWORD} \
  --control-plane-endpoint-ip=${CONTROL_PLANE_ENDPOINT_IP} \
  --self-managed
```

> These are the standard flags; check `nkp create cluster nutanix --help` for the exact set in 2.17.

---

## Troubleshooting

### Harbor
- **`KeyError: 'job_loggers'`** during install → old `harbor.yml`. The current cloud-init fixes this; if hit, replace `/opt/harbor/harbor/harbor.yml` with the corrected one and run `sudo ./install.sh --with-trivy` in `/opt/harbor/harbor`.
- **Containers not up** → `cd /opt/harbor/harbor && sudo docker compose logs --tail=40`.

### Portal / file server (8080)
- **500 error, `open() "...htpasswd" failed (13: Permission denied)`** → nginx can't traverse to the htpasswd file. The current cloud-init puts it at `/etc/nginx/nkp-files.htpasswd` (which nginx can always read). If yours is still under `/opt/harbor/`, move it:
  ```bash
  sudo cp /opt/harbor/nkp-files.htpasswd /etc/nginx/nkp-files.htpasswd
  sudo chmod 0644 /etc/nginx/nkp-files.htpasswd
  sudo sed -i 's#/opt/harbor/nkp-files.htpasswd#/etc/nginx/nkp-files.htpasswd#' /etc/nginx/conf.d/nkp-sources.conf
  sudo nginx -t && sudo systemctl restart nginx
  ```
- **500 error and SELinux is `Enforcing`** → set permissive (see SELinux below) and restart nginx.
- **nginx won't start, `bind() to 0.0.0.0:80 failed`** → nginx's default site collides with Harbor on port 80. The current cloud-init strips it. To fix by hand, remove the `server { listen 80; ... }` block from `/etc/nginx/nginx.conf`, then `sudo nginx -t && sudo systemctl restart nginx`.
- **Connection refused from browser but works via curl on Harbor** → firewall:
  ```bash
  sudo firewall-cmd --permanent --add-port=8080/tcp --add-port=8445/tcp
  sudo firewall-cmd --reload
  ```

### Downloader (8445)
- **No response / refused** → check the container is up: `sudo docker ps | grep nkp-downloader`. If missing, rebuild: `cd /opt/harbor/downloader && sudo docker compose up -d --build`.
- **401 on a curl -I** → that's normal (it asks for auth, and doesn't implement HEAD). Test with a GET in a browser, login `admin` / `Harbor12345`.
- **Bottom line:** the downloader is optional. If it misbehaves, use `scp` (Part 3 Option B) — the portal/file server (8080) serves whatever you scp in.

### Name resolves to IPv6 / `fe80::...`
- `registry.emeagso2026.local` returning only `fe80::` means no proper DNS A record. Either add the DNS record `registry → 10.68.24.103`, or add to `/etc/hosts` on each host:
  ```bash
  echo "10.68.24.103  registry.emeagso2026.local registry" | sudo tee -a /etc/hosts
  ```

### SELinux
- The current cloud-init sets SELinux **permissive** (logs but doesn't block) to avoid label issues in the lab. To check / set by hand:
  ```bash
  getenforce                                  # Permissive is expected
  sudo setenforce 0                           # permissive now
  sudo sed -i 's/^SELINUX=.*/SELINUX=permissive/' /etc/selinux/config   # persist
  ```

---

## Quick reference — what's where

| Service | URL | Login |
|---|---|---|
| Harbor registry UI | `https://registry.emeagso2026.local` | `admin` / `Harbor12345` |
| Portal (download) | `https://10.68.24.103:8080/` | `admin` / `Harbor12345` |
| Upload portal | `https://10.68.24.103:8445/` | `admin` / `Harbor12345` |
| Lab portal | `https://10.68.24.103:8080/index.html` | `admin` / `Harbor12345` |
| Env builder | `https://10.68.24.103:8080/nkp-env-builder.html` | `admin` / `Harbor12345` |
| Prism Central | `https://pc.emeagso2026.local:9440` | your PC creds |

| Path | What |
|---|---|
| `/data/nkp-sources/` (Harbor) | bundles, env, portal HTML — served + exported |
| `/mnt/nkp-sources/` (bastion) | the same dir, mounted over NFS |
| `/opt/harbor/` | Harbor install, certs, scripts |

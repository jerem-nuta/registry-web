# registry-web

Static web pages for the **registry** lab host. They're served by the file
server (port 8080) from `/data/nkp-sources/` and pulled automatically at boot by
the `registry` cloud-init (`GIT_RAW_URL` points at this repo).

---

## What's where — cloud-init vs GitHub

The lab has two halves. Knowing which holds what keeps secrets out of git and
makes deploys self-contained.

### This GitHub repo (`registry-web`) — public, web pages only

Just the static front-end. No secrets. Fetched at boot.

| File | Purpose |
|------|---------|
| `index.html` | Lab portal / landing page (architecture diagram + links to every service) |
| `nkp-env-builder.html` | Form that generates `nkp-deploy.env`; **Connect to PC** button lists images/subnets live |
| `nkp-downloader.html` | Static link portal — paste Nutanix signed links (air-gap bundle + CLI) -> get the ready `curl` |
| `README.md` | This file |

These are the **only** files the cloud-init pulls from GitHub. Self-contained
single files, no build step.

### The cloud-init (lives in the private `nkp` repo / on the box) — everything else

The `registry` cloud-init builds the whole host and **embeds** the services,
so they don't need to come from git:

- **Harbor** registry (UI :443) + Docker Hub proxy cache + version-named NKP mirror
- **nginx file server** (:8080) — serves `/data/nkp-sources/` with basic auth; auto-fetches the 3 pages above
- **Downloader / PC backend** (:8445, HTTPS) — embedded Python service: one-click bundle download **and** the live "Connect to PC -> list images/subnets" used by the env builder
- **NFS export** of `/data/nkp-sources` to the bastion
- **PKI**: real Windows-CA cert (placeholder, you drop it in) **or** self-generated demo PKI
- **SELinux** permissive, port-80 strip, generated file-server password (shown in MOTD)

The cloud-init also carries the **secrets** (cert/key, generated passwords), which
is exactly why it is **not** in this public repo.

### Never in git

`*.key`, the real-cert cloud-init (has the private key), `nkp-deploy.env` with real
values (`NUTANIX_PASSWORD`), and any password files. Use a least-privilege Prism
Central service account (see `PC-SERVICE-ACCOUNT.md`) so the env-file credential is
scoped to NKP operations only.

---

## How the pages are consumed

The cloud-init has:

```bash
GIT_RAW_URL="https://raw.githubusercontent.com/jerem-nuta/registry-web/main"
```

At boot it downloads `index.html`, `nkp-env-builder.html`, and `nkp-downloader.html`
into `/data/nkp-sources/`; the file server (8080) serves them. Edit a page, push,
and the next deploy pulls the new version. To refresh a running box without
redeploying:

```bash
cd /data/nkp-sources
for f in index.html nkp-env-builder.html nkp-downloader.html; do
  sudo curl -fsSL "https://raw.githubusercontent.com/jerem-nuta/registry-web/main/$f" -o "$f"
done
sudo restorecon -Rv /data/nkp-sources 2>/dev/null
```

---

## Editing

Hostnames/IPs inside are lab defaults (`registry.emeagso2026.local`,
`10.68.24.0/27`). Edit the `href` values / field defaults to match your environment.
The env builder's **Connect to PC** calls the backend at
`https://<this-host>:8445` — that service is part of the cloud-init, not this repo.
